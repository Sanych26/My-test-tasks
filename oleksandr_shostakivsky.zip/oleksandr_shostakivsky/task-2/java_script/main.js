/**
 * number of pictures
 **/
var images = document.getElementsByClassName('elem');
var number = images.length;
document.getElementById("countImg").innerHTML = number;


/**
 * current date
 **/
var date = new Date();
var year = date.getFullYear();
const month = String(date.getMonth() + 1).padStart(2, '0');
var day = date.getDate();
var hours = date.getHours();
var minutes = date.getMinutes();
var fullDate = day + '.' + month + '.' + year + ' ' + hours + ':' + minutes;
document.getElementById("date").innerHTML = fullDate;


/**
 * click on image
 **/
$(function() {
  $(".elem img").on("click", function() {
    $(".images-back").show();
    $(".esc").show();
    $(".deleteImg").hide();
    $(this).css({
      "width": "auto",
      "height": "auto",
      "transform": "rotate(0deg)",
      "border-radius": "0px"
    });
    $(this).parent().css({
      "width": "100%",
      "height": "100%",
      "display": "flex",
      "position": "fixed"
    });
  });

  $(".esc").on("click", function() {
    $(".images-back").hide();
    $(".esc").hide();
    $(".deleteImg").show();
    $(".elem img").css({
      "width": "250px",
      "height": "250px",
      "border-radius": "50%"
    });
    $(".elem").css({
      "width": "auto",
      "height": "auto",
      "display": "inline-block",
      "position": "static"
    });
  });


  /**
   * hide image
   **/
  var listElements = JSON.parse(window.localStorage.getItem('hiddenImg'));
  if (!listElements) {
    listElements = [];
  }
  $(".deleteImg").on("click", function() {
    $(this).parent().hide();
    listElements.push($(".deleteImg").index($(this)));
    window.localStorage.setItem('hiddenImg', JSON.stringify(listElements));
  });

  $(".deleteImg").each(function(i) {
    var index = $(".deleteImg").index(this);
    if (listElements.find(function(val) {
        return index == val;
      })) {
      $(this).parent().hide();
    }
  });

  $("#showAll").on("click", function() {
    $(".deleteImg").parent().show();
    window.localStorage.clear();
  });
});
