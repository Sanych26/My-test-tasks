/**
 * ajax query
 **/

$(function() {
  $("#send").on("click", function() {
    var value = $("#inpt").val();
    $.get(`http://universities.hipolabs.com/search?country=${value}`, function(result) {
      for (var i = 0; i < result.length; i++) {
        $("tbody").append('<tr><td>' + i + '</td><td>' + result[i].country + '</td><td>' + result[i].name + '</td><td><a href="' + result[i].web_pages + '"  target="_blank">' + result[i].web_pages + '</a></td></tr>')
      }
    }, "json");
  });

  $("#clear").on("click", function() {
    $("#inpt").val('');
    $("tbody").html('');
  });





});
